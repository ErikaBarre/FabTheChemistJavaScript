b();

console.log(a);
//undefined car a est definit dans la suite

var a = 'Hello World!';

function b() {
    console.log('Called b!');
}


function d(){var myvar; console.log(myvar);}

function e(){var myvar=2; 
             console.log(myvar);
             d();
            }

var myvar=1;
console.log(myvar);
e();
console.log(myvar);