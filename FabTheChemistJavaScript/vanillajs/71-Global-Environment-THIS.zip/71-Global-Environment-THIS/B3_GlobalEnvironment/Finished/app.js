var a = 'Hello World!';

function b() {
    
}

//this est window
console.log("variable  this " + this);
console.log("variable  window " + window);

//window object contient a et la function
console.log("variable a" + a);

console.log("variable  a" + window.a);
